﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DW_2021_KelompokCalvin
{
    public partial class DatacubeForm : Form
    {
        private SqlFunction sqlFunc;
        private string sqlQuery;
        private DataTable dataCollectionDt;

        public DatacubeForm()
        {
            InitializeComponent();
        }

        private void DatacubeForm_Load(object sender, EventArgs e)
        {
            //OnLoad DatacubeForm, TODO's:
            //Complete Database Connection Class
            string connString = "datasource=localhost;port=3306;username=root;password=;database=ud_sinar_mas_olap";
            sqlFunc = new SqlFunction(connString);
        }
        private void Radiobutton_CheckedChanged(object sender, EventArgs e)
        {
            ChangedRadioButtonEvent();
            DgvResizer(tampilandataDatagridview);

        }

        /*
        ////////////////////////
        Functions and Procedures
        ////////////////////////
        */

        //Procedure Customer
        private void CustomerData()
        {
            sqlQuery = "SELECT c.nama_customer `Nama Customer`, SUM(tf.quantity) `Jumlah Pembelian`, SUM(tf.sub_total) `Total Pembelian` FROM transaksi_fact tf, customer c WHERE tf.customer_id = c.customer_id GROUP BY c.customer_id;";
            dataCollectionDt = sqlFunc.selectQuery(sqlQuery);
            tampilandataDatagridview.DataSource = dataCollectionDt;
        }

        //Procedure Barang
        private void BarangData()
        {
            sqlQuery = "SELECT b.barang_id `Nama Barang`, SUM(tf.quantity) `Quantity Penjualan`, SUM(tf.sub_total) `Total Penjualan` FROM transaksi_fact tf, barang b WHERE b.barang_id = SUBSTRING(tf.barang_id, 5, 5) GROUP BY b.barang_id;";
            dataCollectionDt = sqlFunc.selectQuery(sqlQuery);
            tampilandataDatagridview.DataSource = dataCollectionDt;
        }

        //Procedure Tanggal
        private void TanggalData()
        {
            sqlQuery = "SELECT CONCAT(d.tanggal, ' ', BulanConverter(d.bulan), ' ', d.tahun) `Tanggal Pembelian`, SUM(tf.quantity) `Quantity Penjualan`, SUM(tf.sub_total) `Total Penjualan` FROM transaksi_fact tf, `date` d WHERE tf.date_id = d.date_id GROUP BY d.date_id ORDER BY d.tahun ASC, d.bulan ASC, d.tanggal ASC;";
            dataCollectionDt = sqlFunc.selectQuery(sqlQuery);
            tampilandataDatagridview.DataSource = dataCollectionDt;
        }

        //Procedure Customer dan Barang
        private void CustomerDanBarangData()
        {
            sqlQuery = "SELECT c.nama_customer `Nama Customer`, CONCAT(b.jenis_barang, ' - ', b.barang_id) `Nama Barang`, SUM(tf.quantity) `Quantity Penjualan`, SUM(tf.sub_total) `Total Penjualan` FROM customer c, barang b, transaksi_fact tf WHERE tf.customer_id = c.customer_id AND b.barang_id = SUBSTRING(tf.barang_id, 5, 5) GROUP BY c.customer_id, b.barang_id;";
            dataCollectionDt = sqlFunc.selectQuery(sqlQuery);
            tampilandataDatagridview.DataSource = dataCollectionDt;
        }


        //Procedure Barang dan Tanggal
        private void BarangDanTanggalData()
        {
            sqlQuery = "SELECT CONCAT(d.tanggal, ' ', BulanConverter(d.bulan), ' ', d.tahun) `Tanggal Pembelian`, CONCAT(b.jenis_barang, ' - ', b.barang_id) `Nama Barang`, SUM(tf.quantity) `Quantity Penjualan`, SUM(tf.sub_total) `Total Penjualan` FROM transaksi_fact tf, barang b, `date` d WHERE d.date_id = tf.date_id AND b.barang_id = SUBSTRING(tf.barang_id, 5, 5) GROUP BY d.date_id, b.barang_id;";
            dataCollectionDt = sqlFunc.selectQuery(sqlQuery);
            tampilandataDatagridview.DataSource = dataCollectionDt;
        }

        //Procedure Tanggal dan Customer
        private void TanggalDanCustomerData()
        {
            sqlQuery = "SELECT CONCAT(d.tanggal, ' ', BulanConverter(d.bulan), ' ', d.tahun) `Tanggal Pembelian`, c.nama_customer `Nama Customer`,  SUM(tf.quantity) `Quantity Penjualan`, SUM(tf.sub_total) `Total Penjualan` FROM transaksi_fact tf, customer c, `date` d WHERE tf.date_id = d.date_id AND c.customer_id = tf.customer_id GROUP BY d.date_id, c.customer_id;";
            dataCollectionDt = sqlFunc.selectQuery(sqlQuery);
            tampilandataDatagridview.DataSource = dataCollectionDt;
        }

        //Datagridview Resize
        private void DgvResizer(DataGridView dgv)
        {
            int columnsCount = dgv.Columns.Count;
            for(int counter = 0; counter < columnsCount; counter++)
            {
                //Convert AutoSize Mode
                dgv.Columns[counter].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;                               
            }
            
            for (int counter = 0; counter < columnsCount; counter++)
            {
                //Resize
                int columnWidth = dgv.Columns[counter].Width;
                dgv.Columns[counter].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dgv.Columns[counter].Width = columnWidth;
            }

        }

        //Changed Event
        private void ChangedRadioButtonEvent()
        {
            if (customerRadiobutton.Checked == true)
            {
                CustomerData();
            }
            else if (barangRadiobutton.Checked == true)
            {
                BarangData();
            }
            else if (tanggalRadiobutton.Checked == true)
            {
                TanggalData();
            }
            else if (customerdanbarangRadiobutton.Checked == true)
            {
                CustomerDanBarangData();
            }
            else if (barangdantanggalRadiobutton.Checked == true)
            {
                BarangDanTanggalData();
            }
            else if (tanggaldancustomerRadiobutton.Checked == true)
            {
                TanggalDanCustomerData();
            }
        }
        
    }
}
