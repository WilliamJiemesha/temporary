﻿
namespace DW_2021_KelompokCalvin
{
    partial class DatacubeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerRadiobutton = new System.Windows.Forms.RadioButton();
            this.customerdanbarangRadiobutton = new System.Windows.Forms.RadioButton();
            this.barangdantanggalRadiobutton = new System.Windows.Forms.RadioButton();
            this.barangRadiobutton = new System.Windows.Forms.RadioButton();
            this.tanggaldancustomerRadiobutton = new System.Windows.Forms.RadioButton();
            this.tanggalRadiobutton = new System.Windows.Forms.RadioButton();
            this.tampilandataDatagridview = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.tampilandataDatagridview)).BeginInit();
            this.SuspendLayout();
            // 
            // customerRadiobutton
            // 
            this.customerRadiobutton.AutoSize = true;
            this.customerRadiobutton.Location = new System.Drawing.Point(12, 23);
            this.customerRadiobutton.Name = "customerRadiobutton";
            this.customerRadiobutton.Size = new System.Drawing.Size(69, 17);
            this.customerRadiobutton.TabIndex = 0;
            this.customerRadiobutton.TabStop = true;
            this.customerRadiobutton.Text = "Customer";
            this.customerRadiobutton.UseVisualStyleBackColor = true;
            this.customerRadiobutton.CheckedChanged += new System.EventHandler(this.Radiobutton_CheckedChanged);
            // 
            // customerdanbarangRadiobutton
            // 
            this.customerdanbarangRadiobutton.AutoSize = true;
            this.customerdanbarangRadiobutton.Location = new System.Drawing.Point(12, 46);
            this.customerdanbarangRadiobutton.Name = "customerdanbarangRadiobutton";
            this.customerdanbarangRadiobutton.Size = new System.Drawing.Size(127, 17);
            this.customerdanbarangRadiobutton.TabIndex = 1;
            this.customerdanbarangRadiobutton.TabStop = true;
            this.customerdanbarangRadiobutton.Text = "Customer dan Barang";
            this.customerdanbarangRadiobutton.UseVisualStyleBackColor = true;
            this.customerdanbarangRadiobutton.CheckedChanged += new System.EventHandler(this.Radiobutton_CheckedChanged);
            // 
            // barangdantanggalRadiobutton
            // 
            this.barangdantanggalRadiobutton.AutoSize = true;
            this.barangdantanggalRadiobutton.Location = new System.Drawing.Point(219, 46);
            this.barangdantanggalRadiobutton.Name = "barangdantanggalRadiobutton";
            this.barangdantanggalRadiobutton.Size = new System.Drawing.Size(122, 17);
            this.barangdantanggalRadiobutton.TabIndex = 3;
            this.barangdantanggalRadiobutton.TabStop = true;
            this.barangdantanggalRadiobutton.Text = "Barang dan Tanggal";
            this.barangdantanggalRadiobutton.UseVisualStyleBackColor = true;
            this.barangdantanggalRadiobutton.CheckedChanged += new System.EventHandler(this.Radiobutton_CheckedChanged);
            // 
            // barangRadiobutton
            // 
            this.barangRadiobutton.AutoSize = true;
            this.barangRadiobutton.Location = new System.Drawing.Point(219, 23);
            this.barangRadiobutton.Name = "barangRadiobutton";
            this.barangRadiobutton.Size = new System.Drawing.Size(59, 17);
            this.barangRadiobutton.TabIndex = 2;
            this.barangRadiobutton.TabStop = true;
            this.barangRadiobutton.Text = "Barang";
            this.barangRadiobutton.UseVisualStyleBackColor = true;
            this.barangRadiobutton.CheckedChanged += new System.EventHandler(this.Radiobutton_CheckedChanged);
            // 
            // tanggaldancustomerRadiobutton
            // 
            this.tanggaldancustomerRadiobutton.AutoSize = true;
            this.tanggaldancustomerRadiobutton.Location = new System.Drawing.Point(419, 46);
            this.tanggaldancustomerRadiobutton.Name = "tanggaldancustomerRadiobutton";
            this.tanggaldancustomerRadiobutton.Size = new System.Drawing.Size(132, 17);
            this.tanggaldancustomerRadiobutton.TabIndex = 5;
            this.tanggaldancustomerRadiobutton.TabStop = true;
            this.tanggaldancustomerRadiobutton.Text = "Tanggal dan Customer";
            this.tanggaldancustomerRadiobutton.UseVisualStyleBackColor = true;
            this.tanggaldancustomerRadiobutton.CheckedChanged += new System.EventHandler(this.Radiobutton_CheckedChanged);
            // 
            // tanggalRadiobutton
            // 
            this.tanggalRadiobutton.AutoSize = true;
            this.tanggalRadiobutton.Location = new System.Drawing.Point(419, 23);
            this.tanggalRadiobutton.Name = "tanggalRadiobutton";
            this.tanggalRadiobutton.Size = new System.Drawing.Size(64, 17);
            this.tanggalRadiobutton.TabIndex = 4;
            this.tanggalRadiobutton.TabStop = true;
            this.tanggalRadiobutton.Text = "Tanggal";
            this.tanggalRadiobutton.UseVisualStyleBackColor = true;
            this.tanggalRadiobutton.CheckedChanged += new System.EventHandler(this.Radiobutton_CheckedChanged);
            // 
            // tampilandataDatagridview
            // 
            this.tampilandataDatagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tampilandataDatagridview.Location = new System.Drawing.Point(12, 101);
            this.tampilandataDatagridview.Name = "tampilandataDatagridview";
            this.tampilandataDatagridview.Size = new System.Drawing.Size(539, 414);
            this.tampilandataDatagridview.TabIndex = 6;
            // 
            // DatacubeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 520);
            this.Controls.Add(this.tampilandataDatagridview);
            this.Controls.Add(this.tanggaldancustomerRadiobutton);
            this.Controls.Add(this.tanggalRadiobutton);
            this.Controls.Add(this.barangdantanggalRadiobutton);
            this.Controls.Add(this.barangRadiobutton);
            this.Controls.Add(this.customerdanbarangRadiobutton);
            this.Controls.Add(this.customerRadiobutton);
            this.Name = "DatacubeForm";
            this.Text = "Datacube";
            this.Load += new System.EventHandler(this.DatacubeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tampilandataDatagridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton customerRadiobutton;
        private System.Windows.Forms.RadioButton customerdanbarangRadiobutton;
        private System.Windows.Forms.RadioButton barangdantanggalRadiobutton;
        private System.Windows.Forms.RadioButton barangRadiobutton;
        private System.Windows.Forms.RadioButton tanggaldancustomerRadiobutton;
        private System.Windows.Forms.RadioButton tanggalRadiobutton;
        private System.Windows.Forms.DataGridView tampilandataDatagridview;
    }
}

